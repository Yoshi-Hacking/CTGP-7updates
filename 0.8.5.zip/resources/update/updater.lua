function startupdate(update_old)
	update_ver = updateinfo(update_old)
	--Screen Draw
	Screen.waitVblankStart()
	Screen.refresh()
	Font.setPixelSizes(font, 24)
	Graphics.initBlend(BOTTOM_SCREEN)
	Graphics.drawImage(0, 0, submen0)
	Graphics.termBlend()
	Font.print(font,10,10,"Downloading "..update_ver.."...",Color.new(255,0,0), BOTTOM_SCREEN)
	Font.print(font,10,50,"Installing "..update_ver.."...",Color.new(255,255,255), BOTTOM_SCREEN)
	Screen.flip()
	--Download zip.
	if not Network.isWifiEnabled() then
		doexitapp()
	end
	System.deleteDirectory(System.currentDirectory().."updates")
	System.createDirectory(System.currentDirectory().."updates")
	socket_downloadfile("raw.githubusercontent.com", "raw.githubusercontent.com", 443, "/mariohackandglitch/CTGP-7updates/master/"..update_ver..".zip", 32768, MAX_RAM_ALLOCATION, 10000, System.currentDirectory().."updates/"..update_ver..".zip", true, "update")
	Font.setPixelSizes(font, 24)
	if not System.doesFileExist(System.currentDirectory().."updates/"..update_ver..".zip") then
		doexitapp()
	end
	--Screen Draw
	Screen.waitVblankStart()
	Screen.refresh()
	Screen.clear(BOTTOM_SCREEN)
	Graphics.initBlend(BOTTOM_SCREEN)
	Graphics.drawImage(0, 0, submen0)
	Graphics.termBlend()
	Font.print(font,10,10,"Downloading "..update_ver.." Done!",Color.new(255,255,255), BOTTOM_SCREEN)
	Font.print(font,10,50,"Installing "..update_ver.."...",Color.new(255,0,0), BOTTOM_SCREEN)
	Screen.flip()
	--Extract zip
	System.extractZIP(System.currentDirectory().."updates/"..update_ver..".zip",System.currentDirectory())
	--Exit app
	Screen.waitVblankStart()
	Screen.refresh()
	Screen.clear(BOTTOM_SCREEN)
	Graphics.initBlend(BOTTOM_SCREEN)
	Graphics.drawImage(0, 0, submen0)
	Graphics.termBlend()
	Font.print(font,10,10,"Downloading "..update_ver.." Done!",Color.new(255,255,255), BOTTOM_SCREEN)
	Font.print(font,10,50,"Installing "..update_ver.." Done!",Color.new(255,255,255), BOTTOM_SCREEN)
	Screen.flip()
	System.deleteFile(System.currentDirectory().."updates/"..update_ver..".zip")
	Screen.waitVblankStart()
	Screen.refresh()
	Screen.clear(BOTTOM_SCREEN)
	Screen.flip()
	dofile(System.currentDirectory().."script.lua")
end