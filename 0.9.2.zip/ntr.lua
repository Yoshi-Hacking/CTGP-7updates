function getntrcontrol()
	GC_key = Controls.read()
	GC_x,GC_y = Controls.readCirclePad()
	GC_outkey = ""
	if (Controls.check(GC_key,KEY_A)) and not(Controls.check(GC_oldkey,KEY_A)) then
		GC_outkey = "A"
	elseif (Controls.check(GC_key,KEY_B)) and not(Controls.check(GC_oldkey,KEY_B)) then
		GC_outkey = "B"
	elseif (Controls.check(GC_key,KEY_Y)) then
		GC_outkey = "Y"
		hold = true
	elseif (Controls.check(GC_key,KEY_START)) and not(Controls.check(GC_oldkey,KEY_START)) then
		GC_outkey = "START"
	end
	if (Timer.getTime(ctrl_timer) >= 500) then
		Timer.reset(ctrl_timer)
		GC_oldkey = KEY_X
		GC_oldx = 0
		GC_oldy = 0
	end
	if (((Controls.check(GC_key,KEY_DLEFT)) and not(Controls.check(GC_oldkey,KEY_DLEFT))) or ((GC_x < -128) and not (GC_oldx < -128))) then
		GC_outkey = "Left"
		Timer.reset(ctrl_timer)
	elseif (((Controls.check(GC_key,KEY_DRIGHT)) and not(Controls.check(GC_oldkey,KEY_DRIGHT))) or ((GC_x > 128) and not (GC_oldx > 128))) then
		GC_outkey = "Right"
		Timer.reset(ctrl_timer)
	elseif (((Controls.check(GC_key,KEY_DUP)) and not(Controls.check(GC_oldkey,KEY_DUP))) or ((GC_y > 128) and not (GC_oldy > 128))) then
		GC_outkey = "Up"
		Timer.reset(ctrl_timer)
	elseif (((Controls.check(GC_key,KEY_DDOWN)) and not(Controls.check(GC_oldkey,KEY_DDOWN))) or ((GC_y < -128) and not (GC_oldy < -128))) then
		GC_outkey = "Down"
		Timer.reset(ctrl_timer)
	end
	GC_oldkey = GC_key
	GC_oldx = GC_x
	GC_oldy = GC_y
	return GC_outkey
end
function initntrapp()
	--Init sockets
	Socket.init()
	--Load Graphics
	submen0 = Graphics.loadImage(System.currentDirectory().."resources/submen0.png")
	-- Do file
	dofile(System.currentDirectory().."downloader.lua")
	-- Bool
	ntrinstalled = true
	hold = false
	-- Int
	MAX_RAM_ALLOCATION = 10485760
	-- Control
	GC_key = 0
	GC_x,GC_y = 0
	GC_oldkey = GC_key
	GC_oldx = GC_x
	GC_oldy = GC_y
	-- Config
	GC_key = Controls.read()
	GC_oldkey = GC_key
	gotconfig = getconfig()
	if not (checkapp(0x00b00000, false)) then
		installntr = true
		ntrinstalled = false
	end
	-- Timer
	ctrl_timer = Timer.new()
	start_timer = Timer.new()
end
System.currentDirectory("/CTGP-7/")
Graphics.init()
font = Font.load(System.currentDirectory().."resources/font.ttf")
Screen.waitVblankStart()
Screen.refresh()
Font.setPixelSizes(font, 32)
Font_center(font, "Launching NTR,",Color.new(255,255,255), BOTTOM_SCREEN, nil, 88)
Font_center(font, "hold Y to update it",Color.new(255,255,255), BOTTOM_SCREEN, nil, 120)
Screen.flip()
initntrapp()
while true do
	checkbutton = true
	pad = getntrcontrol()
	Screen.waitVblankStart()
	Screen.refresh()
	Screen.clear(BOTTOM_SCREEN)
	if installntr then
		Font.setPixelSizes(font, 16)
		Graphics.initBlend(BOTTOM_SCREEN)
		Graphics.drawImage(0, 0, submen0)
		Graphics.termBlend()
		Font_center(font,"Would you like to download", Color.new(255,255,255), BOTTOM_SCREEN, nil, 0)
		Font_center(font,"lastest BootNTR version?", Color.new(255,255,255), BOTTOM_SCREEN, nil, 18)
		Font_center(font,"Press A to update or B to cancel.", Color.new(255,255,255), BOTTOM_SCREEN, nil, 36)
		if (pad == "A") and (checkbutton) then
			if (Network.isWifiEnabled()) then
				--
				Screen.waitVblankStart()
				Screen.refresh()
				Screen.clear(TOP_SCREEN)
				Screen.clear(BOTTOM_SCREEN)
				Graphics.initBlend(BOTTOM_SCREEN)
				Graphics.drawImage(0, 0, submen0)
				Graphics.termBlend()
				Font_center(font,"Downloading...", Color.new(255,255,255), BOTTOM_SCREEN)
				Screen.flip()
				--
				System.deleteDirectory(System.currentDirectory().."ntr")
				System.createDirectory(System.currentDirectory().."ntr")
				socket_downloadfile("raw.githubusercontent.com", "raw.githubusercontent.com", 443, "/mariohackandglitch/CTGP-7updates/master/ntr.zip", 32768, MAX_RAM_ALLOCATION, 10000, System.currentDirectory().."ntr/ntr.zip", true, "ntr")
				if not (System.doesFileExist(System.currentDirectory().."ntr/ntr.zip")) then
					--
					Screen.waitVblankStart()
					Screen.refresh()
					Screen.clear(TOP_SCREEN)
					Screen.clear(BOTTOM_SCREEN)
					Graphics.initBlend(BOTTOM_SCREEN)
					Graphics.drawImage(0, 0, submen0)
					Graphics.termBlend()
					Font_center(font,"Download failed,", Color.new(255,255,255), BOTTOM_SCREEN)
					--
					exitapp()
				end
				--
				Screen.waitVblankStart()
				Screen.refresh()
				Screen.clear(TOP_SCREEN)
				Screen.clear(BOTTOM_SCREEN)
				Graphics.initBlend(BOTTOM_SCREEN)
				Graphics.drawImage(0, 0, submen0)
				Graphics.termBlend()
				Font_center(font,"Extracting...", Color.new(255,255,255), BOTTOM_SCREEN)
				Screen.flip()
				--
				System.extractZIP(System.currentDirectory().."ntr/ntr.zip",System.currentDirectory().."ntr")
				--
				if (ntrinstalled) then
					--
					Screen.waitVblankStart()
					Screen.refresh()
					Screen.clear(BOTTOM_SCREEN)
					Screen.clear(TOP_SCREEN)
					Graphics.initBlend(BOTTOM_SCREEN)
					Graphics.drawImage(0, 0, submen0)
					Graphics.termBlend()
					Font_center(font,"Uninstalling...", Color.new(255,255,255), BOTTOM_SCREEN)
					Screen.flip()
					--
					if (cia_list[ntrlist_id].unique_id == 0x00b00000) then
						System.uninstallCIA(cia_list[ntrlist_id].access_id,SDMC)
					else
						exitapp()
					end
				end
				Screen.waitVblankStart()
				Screen.refresh()
				Screen.clear(BOTTOM_SCREEN)
				Screen.clear(TOP_SCREEN)
				Graphics.initBlend(BOTTOM_SCREEN)
				Graphics.drawImage(0, 0, submen0)
				Graphics.termBlend()
				Font_center(font,"Installing...", Color.new(255,255,255), BOTTOM_SCREEN)
				Screen.flip()
				--
				System.installCIA(System.currentDirectory().."ntr/ntr.cia",1)
				System.deleteFile("/ntr.bin")
				System.renameFile(System.currentDirectory().."ntr/ntr.bin","/ntr.bin")
				System.deleteFile(System.currentDirectory().."ntr/ntr.zip")
				System.deleteFile(System.currentDirectory().."ntr/ntr.cia")
				System.deleteDirectory(System.currentDirectory().."ntr")
				--
				Screen.waitVblankStart()
				Screen.refresh()
				Screen.clear(BOTTOM_SCREEN)
				Screen.clear(TOP_SCREEN)
				Graphics.initBlend(BOTTOM_SCREEN)
				Graphics.drawImage(0, 0, submen0)
				Graphics.termBlend()
				Font_center(font,"Done!", Color.new(255,255,255), BOTTOM_SCREEN)
				installntr = false
				hold = false
			else
				Screen.waitVblankStart()
				Screen.refresh()
				Screen.clear(BOTTOM_SCREEN)
				Screen.clear(TOP_SCREEN)
				Graphics.initBlend(BOTTOM_SCREEN)
				Graphics.drawImage(0, 0, submen0)
				Graphics.termBlend()
				Font_center(font,"No internet access", Color.new(255,255,255), BOTTOM_SCREEN)
				exitapp()
			end
		elseif (pad == "B") and (checkbutton) then
			if ntrinstalled then
				checkbutton = false
				installntr = false
				hold = false
			else
				exitapp()
			end
		end
	elseif hold and (checkbutton) then
		hold = false
		checkbutton = false
		installntr = true
	elseif (Timer.getTime(start_timer) >= 1000) then
		Socket.term()
		Graphics.freeImage(submen0)
		Graphics.term()
		Font.unload(font)
		System.launchCIA(0x00b00000,1)
		System.exit()
	end
	Screen.flip()
end