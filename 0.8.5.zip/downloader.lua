function socket_downloadfile(string_web, string_host, number_port, string_path, number_chunksize, number_writeeach, number_checktimeout, string_savepath, bool_showinfo, string_anim)
	gotresponse = true
	code = ""
	if System.doesFileExist(string_savepath) then
		System.deleteFile(string_savepath)
	end
	if bool_showinfo then
		Font.setPixelSizes(font, 18)
	end
	Socket.init()
	Network.addCertificate(System.currentDirectory().."resources/dshack.der")
	datasckt = Socket.connect(string_web, number_port, true)
	sockettimeout = Timer.new()
	--Request
	Socket.send(datasckt, "GET "..string_path.." HTTP/1.0\r\nHost: "..string_host.."\r\n\r\n")
	headerhttp = ""
	while (string.len(headerhttp) == 0) do
		headerhttp = Socket.receive(datasckt, 2048)
		if (Timer.getTime(sockettimeout) > number_checktimeout) then
			return "Timed out!"
		end
	end
	--File size
	_,bytesoffset = string.find(headerhttp, "Length: ") -- Search for the Content-Length data
	if bytesoffset == nil then
		Console.append(console, "byte"..headerhttp)
		while true do
			GC_key = Controls.read()
			Console.show(console)
			if (Controls.check(GC_key,KEY_A)) then
				Socket.temp()
				doexitapp()
			end
		end
	end
	headerhttp = string.sub(headerhttp, bytesoffset) -- Ignore everything until Content-Length
	contentsize = tonumber(string.match(headerhttp, '%d+')) -- Get the value (number of bytes)
	_,contentoffset = string.find(headerhttp, "\r\n\r\n") -- Find the 2 newlines (start of the content)
	if contentoffset == nil then
		Console.append(console, "content"..headerhttp)
		while true do
			GC_key = Controls.read()
			Console.show(console)
			if (Controls.check(GC_key,KEY_A)) then
				doexitapp()
			end
		end
	end
	headerhttp = string.sub(headerhttp, contentoffset + 1) -- Ignore everything but the actual content.
	-- Start Downloading
	databuff = {""}
	fileStream = io.open(string_savepath,FCREATE)
	io.write(fileStream, 0, headerhttp, string.len(headerhttp))
	file_size = io.size(fileStream)
	io.close(fileStream)
	headerhttp = ""
	string_size = 0
	total_size = string_size + file_size
	ori_chunksize = number_chunksize
	if bool_showinfo then
		writetablesize = 1
		writetimes = 0
		prg1 = 40
		prg2 = 40
		speedtmr = Timer.new()
		oldsize = total_size
		progress = ""
		print_w = ""
	end
	if (string_anim == "ntr") then
		Font.setPixelSizes(font, 16)
	end
	Timer.reset(sockettimeout)
	while true do
		if ((total_size + number_chunksize) >= contentsize) then
			number_chunksize = ori_chunksize - ((total_size + ori_chunksize) - contentsize)
			if not (total_size + number_chunksize == contentsize) then
				Socket.term()
				return false
			end
		end
		scktdata = Socket.receive(datasckt, number_chunksize) -- Receive next chunk of data
		recieved_len = string.len(scktdata)
		if (recieved_len > 0) then
			string_size = string_size + recieved_len
			databuff[#databuff + 1] = scktdata
		end
		total_size = file_size + string_size
		if not bool_showinfo then
			if (total_size == contentsize) then
				socket_writetofile(string_savepath, databuff, false)
				databuff = nil
				filedata = ""
				string_size = nil
				total_size = nil
				Timer.destroy(sockettimeout)
				Socket.term()
				return true
			end
			if (string_size >= number_writeeach) then
				socket_writetofile(string_savepath, databuff, false)
				databuff = {}
				filedata = ""
				string_size = 0
				total_size = file_size + string_size
			end
			Timer.reset(sockettimeout)
		elseif bool_showinfo then
			if (total_size == contentsize) then
				socket_writetofile(string_savepath, databuff, true, string_anim)
				databuff = nil
				filedata = ""
				string_size = nil
				total_size = nil
				Timer.destroy(speedtmr)
				Timer.destroy(sockettimeout)
				Socket.term()
				return true
			end
			if (string_size >= number_writeeach) then
				socket_writetofile(string_savepath, databuff, true, string_anim)
				databuff = {}
				filedata = ""
				string_size = 0
				total_size = file_size + string_size
			end
			if (Timer.getTime(speedtmr) >= 1000) then
				progress = (total_size - oldsize)
				oldsize = total_size
				Screen.waitVblankStart()
				Screen.refresh()
				Screen.clear(BOTTOM_SCREEN)
				showinfo(string_anim, true)
				Screen.flip()
				Timer.reset(speedtmr)
			end
			Timer.reset(sockettimeout)
		elseif (Timer.getTime(sockettimeout) > number_checktimeout) then
			System.deleteFile(string_savepath)
			Timer.destroy(sockettimeout)
			if bool_showinfo then
				Timer.destroy(speedtmr)
			end
			Socket.term()
			return "Timed Out"
		end
	end
end
function showinfo(string_anim, bool_download)
	Graphics.initBlend(BOTTOM_SCREEN)
	Graphics.drawImage(0, 0, submen0)
	if (string_anim == "update") then
		if bool_download then
			prg1 = 40 + math.ceil(( total_size / contentsize ) * 240)
		else
			prg2 = 40 + math.ceil(((file_size + ((writetimes / writetablesize) * string_size)) / contentsize) * 240)
		end
		Graphics.fillEmptyRect(40, 280, 142, 172, Color.new(255,255,255))
		Graphics.fillRect(40, prg1, 142, 172,Color.new(255,255,255))
		Graphics.fillEmptyRect(40, 280, 190, 220, Color.new(255,255,255))
		Graphics.fillRect(40, prg2, 190, 220,Color.new(255,255,255))
		Graphics.termBlend()
		Font.setPixelSizes(font, 24)
		Font.print(font,10,10,"Downloading "..update_ver.."...",Color.new(255,0,0), BOTTOM_SCREEN)
		Font.print(font,10,50,"Installing "..update_ver.."...",Color.new(255,255,255), BOTTOM_SCREEN)
		Font.print(font,10,90,"Finishing...",Color.new(255,255,255), BOTTOM_SCREEN)
		Font.setPixelSizes(font, 18)
		Font.print(font,60,196,"Save to SD",Color.new(255,0,0), BOTTOM_SCREEN)
		Font.print(font,60,148,"Download: "..round((progress / 1024),2).." KB/sec",Color.new(255,0,0), BOTTOM_SCREEN)
		Font.print(font,60,172,"Size: "..round((contentsize / 1048576),2).." MB",Color.new(255,0,0), BOTTOM_SCREEN)
	elseif (string_anim == "ntr") then
		if bool_download then
			prg1 = 40 + math.ceil(( total_size / contentsize ) * 240)
		else
			prg2 = 40 + math.ceil(((file_size + ((writetimes / writetablesize) * string_size)) / contentsize) * 240)
		end
		Graphics.fillEmptyRect(40, 280, 142, 172, Color.new(255,255,255))
		Graphics.fillRect(40, prg1, 142, 172,Color.new(255,255,255))
		Graphics.fillEmptyRect(40, 280, 190, 220, Color.new(255,255,255))
		Graphics.fillRect(40, prg2, 190, 220,Color.new(255,255,255))
		Graphics.termBlend()
		Font.print(font,60,196,"Save to SD",Color.new(255,0,0), BOTTOM_SCREEN)
		Font.print(font,60,148,"Download: "..round((progress / 1024),2).." KB/sec",Color.new(255,0,0), BOTTOM_SCREEN)
		Font.print(font,40,172,"Size: "..round((contentsize / 1048576),2).." MB",Color.new(255,0,0), BOTTOM_SCREEN)
	end
end
function socket_writetofile(string_pathfile,array_databuff, bool_showinfo, string_anim)
	fileStream = io.open(string_pathfile,FWRITE)
	filew_size = io.size(fileStream)
	Screen.waitVblankStart()
	Screen.refresh()
	Screen.flip()
	writetablesize = #array_databuff
	writetimes = 1
	fileprogress = total_size / contentsize
	while ((writetimes - 1) ~= writetablesize) do
		if (bool_showinfo) and (Timer.getTime(speedtmr) >= 1000) then
			Screen.waitVblankStart()
			Screen.refresh()
			Screen.clear(BOTTOM_SCREEN)
			showinfo(string_anim, false)
			Screen.flip()
			Timer.reset(speedtmr)
		end
		array_size = string.len(array_databuff[writetimes])
		io.write(fileStream, filew_size, array_databuff[writetimes], array_size)
		filew_size = filew_size + array_size
		writetimes = writetimes + 1
	end
	writetimes = 0
	file_size = io.size(fileStream)
	io.close(fileStream)
end