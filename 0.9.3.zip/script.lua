function getcontrol()
	GC_key = Controls.read()
	GC_x,GC_y = Controls.readCirclePad()
	GC_outkey = ""
	if (Controls.check(GC_key,KEY_A)) and not(Controls.check(GC_oldkey,KEY_A)) then
		GC_outkey = "A"
	elseif (Controls.check(GC_key,KEY_B)) and not(Controls.check(GC_oldkey,KEY_B)) then
		GC_outkey = "B"
	elseif (Controls.check(GC_key,KEY_Y)) and not(Controls.check(GC_oldkey,KEY_Y)) then
		GC_outkey = "Y"
	elseif (Controls.check(GC_key,KEY_START)) and not(Controls.check(GC_oldkey,KEY_START)) then
		GC_outkey = "START"
	end
	if (Timer.getTime(ctrl_timer) >= 500) then
		Timer.reset(ctrl_timer)
		GC_oldkey = KEY_X
		GC_oldx = 0
		GC_oldy = 0
	end
	if (((Controls.check(GC_key,KEY_DLEFT)) and not(Controls.check(GC_oldkey,KEY_DLEFT))) or ((GC_x < -128) and not (GC_oldx < -128))) then
		GC_outkey = "Left"
		Timer.reset(ctrl_timer)
	elseif (((Controls.check(GC_key,KEY_DRIGHT)) and not(Controls.check(GC_oldkey,KEY_DRIGHT))) or ((GC_x > 128) and not (GC_oldx > 128))) then
		GC_outkey = "Right"
		Timer.reset(ctrl_timer)
	elseif (((Controls.check(GC_key,KEY_DUP)) and not(Controls.check(GC_oldkey,KEY_DUP))) or ((GC_y > 128) and not (GC_oldy > 128))) then
		GC_outkey = "Up"
		Timer.reset(ctrl_timer)
	elseif (((Controls.check(GC_key,KEY_DDOWN)) and not(Controls.check(GC_oldkey,KEY_DDOWN))) or ((GC_y < -128) and not (GC_oldy < -128))) then
		GC_outkey = "Down"
		Timer.reset(ctrl_timer)
	end
	GC_oldkey = GC_key
	GC_oldx = GC_x
	GC_oldy = GC_y
	return GC_outkey
end
function listDirectory(dir)
	dir = System.listDirectory(dir)
	files_table = {}
	for i,file in pairs(dir) do
		if not file.directory then
			table.insert(files_table,file)
		end
	end
	table.sort(files_table, function (a, b) return (a.name:lower() < b.name:lower() ) end)
	return files_table
end
function getconfig()
	dofile(System.currentDirectory().."config/config.lua")
	trackn = #tracks
	tracke = {}
	local i
	for i = 1, trackn, 1 do
		if (System.doesFileExist(System.currentDirectory().."gamefs/Course/"..tracks[i].."_.szs")) then
			tracke[i] = false
		else
			tracke[i] = true
		end
	end
	debugaddentry(12)
	if (System.doesFileExist("/plugin/0004000000030600/layeredfs.plg")) then
		MK7_TID = "0004000000030600"
	elseif (System.doesFileExist("/plugin/0004000000030700/layeredfs.plg")) then
		MK7_TID = "0004000000030700"
	elseif (System.doesFileExist("/plugin/0004000000030800/layeredfs.plg")) then
		MK7_TID = "0004000000030800"
	else
		Screen.waitVblankStart()
		Screen.refresh()
		Screen.clear(BOTTOM_SCREEN)
		Font_center(font, "Missing NTR plugin.", Color.new(255,255,255), BOTTOM_SCREEN)
		Screen.flip()
		Graphics.freeImage(topimgl)
		Graphics.freeImage(topimgr)
		Graphics.freeImage(submen0)
		Graphics.freeImage(btn_bg)
		Graphics.freeImage(btn_wr)
		Graphics.freeImage(btn_disen)
		Graphics.freeImage(btn_u)
		Graphics.freeImage(btn_s)
		Graphics.term()
		Font.unload(font)
		System.exit()
	end
	debugaddentry(13)
	if not (#cts == trackn) then
		return false
	end
	settings = {}
	settings[1] = false
	settings[2] = false
	if (System.doesFileExist("/plugin/"..MK7_TID.."/cheat.plg")) then
		settings[1] = true
	end
	if (System.doesFileExist("/plugin/"..MK7_TID.."/LED_trick.plg")) then
		settings[2] = true
	end
	return true
end
function applyconfig()
	local z
	for z = 1, trackn, 1 do
		if (System.doesFileExist(System.currentDirectory().."gamefs/Course/"..tracks[z]..".szs")) then
			if not (tracke[z]) then
				System.renameFile(System.currentDirectory().."gamefs/Course/"..tracks[z]..".szs", System.currentDirectory().."gamefs/Course/"..tracks[z].."_.szs")
			end
		elseif (System.doesFileExist(System.currentDirectory().."gamefs/Course/"..tracks[z].."_.szs")) then
			if (tracke[z]) then
				System.renameFile(System.currentDirectory().."gamefs/Course/"..tracks[z].."_.szs", System.currentDirectory().."gamefs/Course/"..tracks[z]..".szs")
			end
		end
	end
	if (settings[1]) and not System.doesFileExist("/plugin/"..MK7_TID.."/cheat.plg") then
		CopyFile(System.currentDirectory().."resources/cheat.plg","/plugin/"..MK7_TID.."/cheat.plg")
	elseif not (settings[1]) and System.doesFileExist("/plugin/"..MK7_TID.."/cheat.plg") then
		System.deleteFile("/plugin/"..MK7_TID.."/cheat.plg")
	end
	if (settings[2]) and not System.doesFileExist("/plugin/"..MK7_TID.."/LED_trick.plg") then
		CopyFile(System.currentDirectory().."resources/LED_trick.plg","/plugin/"..MK7_TID.."/LED_trick.plg")
	elseif not (settings[2]) and System.doesFileExist("/plugin/"..MK7_TID.."/LED_trick.plg") then
		System.deleteFile("/plugin/"..MK7_TID.."/LED_trick.plg")
	end
	return true
end
function CopyFile(input,output)
	inp = io.open(input,FREAD)
	if System.doesFileExist(output) then
		System.deleteFile(output)
	end
	out = io.open(output,FCREATE)
	size = io.size(inp)
	index = 0
	while (index+(MAX_RAM_ALLOCATION/2) < size) do
		io.write(out,index,io.read(inp,index,MAX_RAM_ALLOCATION/2),(MAX_RAM_ALLOCATION/2))
		index = index + (MAX_RAM_ALLOCATION/2)
	end
	if index < size then
		io.write(out,index,io.read(inp,index,size-index),(size-index))
	end
	io.close(inp)
	io.close(out)
end
function checkapp(TID,bool_prod)
	cia_list = {}
	cia_list = System.listCIA()
	local installed = false
	cia_count = #cia_list
	ntrlist_id = 0
	debugaddentry(9)
	if (bool_prod == false) then
		for v = 1, cia_count, 1 do
			if (cia_list[v].unique_id == TID) then
				installed = true
				ntrlist_id = v
				break
			else
				installed = false
			end
		end
	elseif (bool_prod == true) then
		for v = 1, cia_count, 1 do
			if (cia_list[v].product_id == TID) then
				installed = true
				break
			else
				installed = false
			end
		end
	end
	v = nil
	return installed
end
function round(num, idp, hour)
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end
function Font_center(fontID, string_text, color, screentarget, defX, defY, defZ)
	if (screentarget == BOTTOM_SCREEN) then
		fnt_sizex, fnt_sizey = Font.measureText(fontID, string_text, 320)
		if (defX == nil) then
			fnt_posX = math.modf((320 - fnt_sizex)/2)
		else
			fnt_posX = defX
		end
		if (defY == nil) then
			fnt_posY = math.modf((240 - fnt_sizey)/2)
		else
			fnt_posY = defY
		end
		Font.print(fontID, fnt_posX, fnt_posY, string_text, color, screentarget, 0, 320)
	else
		fnt_sizex, fnt_sizey = Font.measureText(fontID, string_text, 400)
		if (defX == nil) then
			fnt_posX1 = math.modf((400 - fnt_sizex)/2 + defZ/2)
			fnt_posX2 = math.modf((400 - fnt_sizex)/2 - defZ/2)
		else
			fnt_posX1 = defX + defZ/2
			fnt_posX2 = defX - defZ/2
		end
		if (defY == nil) then
			fnt_posY = math.modf((240 - fnt_sizey)/2)
		else
			fnt_posY = defY
		end
		Font.print(fontID, fnt_posX1, fnt_posY, string_text, color, screentarget, 0, 400)
		Font.print(fontID, fnt_posX2, fnt_posY, string_text, color, screentarget, 1, 400)
	end
end
function SecondsToClock(seconds)
  local seconds = tonumber(seconds)

  if seconds <= 0 then
    return "00:00:00";
  else
    hours = string.format("%02.f", math.floor(seconds/3600));
    mins = string.format("%02.f", math.floor(seconds/60 - (hours*60)));
    secs = string.format("%02.f", math.floor(seconds - hours*3600 - mins *60));
    return hours..":"..mins..":"..secs
  end
end
function checkupdate()
	if (Network.isWifiEnabled()) then
		Font.setPixelSizes(font, 14)
		if socket_downloadfile("raw.githubusercontent.com", "raw.githubusercontent.com", 443, "/mariohackandglitch/CTGP-7updates/master/array_ver.lua", 32768, MAX_RAM_ALLOCATION, 10000, System.currentDirectory().."array_ver.lua", false, nil) then
			dofile(System.currentDirectory().."array_ver.lua")
			System.deleteFile(System.currentDirectory().."array_ver.lua")
		else
			return false,false
		end
		debugaddentry(17)
		uinfo_entries = #array_ver
		oldness = uinfo_entries
		local i = 1
		for i = 1, uinfo_entries, 1 do
			ver = array_ver[oldness]
			if (local_ver == ver) then
				if (oldness == 1) then
					trueoldness = false
				else
					trueoldness = oldness
				end
				break
			elseif (oldness <= 1) then
				trueoldness = false
				break
			end
			oldness = oldness - 1
		end
		return true,trueoldness
	else
		return false,false
	end
end
function exitapp()
	--Stupid lpp3ds bugs ;_;
	Screen.disable3D()
	appexit = true
end
function doexitapp()
	Console.destroy(console)
	Sound.pause(bgm)
	Sound.close(bgm)
	Sound.close(beep)
	Sound.term()
	Graphics.freeImage(topimgl)
	Graphics.freeImage(topimgr)
	Graphics.freeImage(submen0)
	Graphics.freeImage(btn_bg)
	Graphics.freeImage(btn_wr)
	Graphics.freeImage(btn_disen)
	Graphics.freeImage(btn_u)
	Graphics.freeImage(btn_s)
	Graphics.term()
	Font.unload(font)
	System.exit()
end
function finishinstall()
	if (System.doesFileExist(System.currentDirectory().."resources/update/updater.lua")) then
		System.deleteFile(System.currentDirectory().."updater.lua")
		System.renameFile(System.currentDirectory().."resources/update/updater.lua",System.currentDirectory().."updater.lua")
	end
	if (System.doesFileExist(System.currentDirectory().."resources/update/CTGP-7.cia")) then
		font = Font.load(System.currentDirectory().."resources/font.ttf")
		Font.setPixelSizes(font, 32)
		Screen.waitVblankStart()
		Screen.refresh()
		Screen.clear(BOTTOM_SCREEN)
		Font.print(font,82,104,"Updating...",Color.new(255,255,255), BOTTOM_SCREEN)
		Screen.flip()
		handle = io.open(System.currentDirectory().."resources/updater.cia",FREAD)
		file_size = io.size(handle)
		ret = Core.execCall("amInit")
		if not ret == 0 then
			error("amInit returned an error: 0x" .. string.format("%X",ret))
		end
		cia_handle = Core.alloc(0x04)
		ret = Core.execCall("AM_StartCiaInstall", 0x01, cia_handle)
		if not ret == 0 then
			error("AM_StartCiaInstall returned an error: 0x" .. string.format("%X",ret))
		end
		tmp = Core.readWord(cia_handle)
		content = Core.getHandle(tmp)
		i = 0
		BUF_SIZE = 5242880
		while i < file_size do
			block_size = BUF_SIZE
			if i + BUF_SIZE > file_size then
				block_size = file_size - i
			end
			io.write(content,i,io.read(handle, i, block_size),block_size)
			i = i + block_size
		end
		ret = Core.execCall("AM_FinishCiaInstall", cia_handle)
		if not ret == 0 then
			error("AM_FinishCiaInstall returned an error: 0x" .. string.format("%X",ret))
		end
		Core.execCall("amExit")
		io.close(handle)
		io.close(content)
		Core.free(cia_handle)
		Font.unload(font)
		System.launchCIA(0x03070D00,SDMC)
	end
end
function rainbow()
	local red = math.modf(math.sin(0.00202683548*Timer.getTime(rnbw_timer) + 0) * 127 + 128)
	local green = math.modf(math.sin(0.00202683548*Timer.getTime(rnbw_timer) + 2.0943951) * 127 + 128)
	local blue = math.modf(math.sin(0.00202683548*Timer.getTime(rnbw_timer) + 4.1887902) * 127 + 128)
	return red,green,blue
end
function debugaddentry(deb_string)
	if (debug_console) then
		if (deb_string == 17) then
			Console.clear(console)
		end
		debug_timer = Timer.new()
		Screen.waitVblankStart()
		Screen.refresh()
		Screen.clear(TOP_SCREEN)
		Screen.clear(BOTTOM_SCREEN)
		Console.append(console, tostring(deb_string).."\n")
		Console.show(console)
		Screen.flip()
		while (Timer.getTime(debug_timer) <= 500) do
		end
		Timer.destroy(debug_timer)
	end
end
function initapp()
	--Dofile
	dofile(System.currentDirectory().."downloader.lua")
	-- Timer
	debugaddentry(1)
	ctrl_timer = Timer.new()
	rnbw_timer = Timer.new()
	--Init sockets
	debugaddentry(2)
	--SSL certificate
	debugaddentry(3)
	--Load Graphics
	debugaddentry(4)
	submen0 = Graphics.loadImage(System.currentDirectory().."resources/submen0.png")
	btn_u = Graphics.loadImage(System.currentDirectory().."resources/btn_u.png")
	btn_s = Graphics.loadImage(System.currentDirectory().."resources/btn_s.png")
	btn_disen = Graphics.loadImage(System.currentDirectory().."resources/btn_disen.png")
	btn_bg = Graphics.loadImage(System.currentDirectory().."resources/btn_bg.png")
	btn_wr = Graphics.loadImage(System.currentDirectory().."resources/btn_wr.png")
	debugaddentry(5)
	local h,m,s = System.getTime()
	math.randomseed(((m^2)*(math.sqrt(s*891)))+h*s)
	local r = math.random(1,2)
	topimgl = Graphics.loadImage(System.currentDirectory().."resources/top_l"..tostring(r)..".png")
	topimgr = Graphics.loadImage(System.currentDirectory().."resources/top_r"..tostring(r)..".png")
	-- Add notification
	debugaddentry(6)
	if not (System.doesFileExist(System.currentDirectory().."config/first.flag")) then
		System.addNews("Custom tracks Grand Prix - 7 ", "Thanks for installing CTGP-7!.\nHere are some useful features:\n\n200cc:\nTo use 200cc, you must\nenable it first from the manager,\nunder \"Ingame options\".\nAfter launching CTGP-7\npress X + Y, select \"Game Plugin\"\nand enable 200cc for your region.\n\nCourse manager:\nAllows to disable Custom tracks,\nuseful if you like game edits,\nbut don't want Custom tracks.\n\nWARNING\nIf you want to do Time Trials\nin Custom tracks, backup your\nsave first if you care about\nyour previus ghosts,\nsince ending a Custom Track\nin less time than the original ghost,\nwill cause the previous one\nto be overwritted with the new one.\n\nThat's all, hope you enjoy. :3\n\nCTGP-7 team", System.currentDirectory().."resources/notif.jpg", true)
		flag = io.open(System.currentDirectory().."config/first.flag",FCREATE)
		io.write(flag,0,"dummy", 5)
		io.close(flag)
	end
	-- Control
	debugaddentry(7)
	GC_key = Controls.read()
	GC_x,GC_y = Controls.readCirclePad()
	GC_oldkey = GC_key
	GC_oldx = GC_x
	GC_oldy = GC_y
	-- Bool
	debugaddentry(8)
	got_changelog = false
	installntr = false
	showupdate = false
	ntrinstalled = checkapp(0x00b00000, false)
	-- Int
	debugaddentry(10)
	clog_page = 0
	men = 0
	men3 = 1
	disp1 = men3 + 1
	disp2 = men3 - 1
	submen = 0
	MAX_RAM_ALLOCATION = 5242880
	-- Config
	debugaddentry(11)	
	gotconfig = getconfig()
	-- BGM
	debugaddentry(14)
	Sound.init()
	debugaddentry(15)
	beep = Sound.openOgg(System.currentDirectory().."resources/beep.ogg", false)
	beep1 = Sound.openOgg(System.currentDirectory().."resources/beep1.ogg", false)
	bgm = Sound.openOgg(System.currentDirectory().."resources/bgm.ogg", true)
	-- Update check
	debugaddentry(16)
	dofile(System.currentDirectory().."updater.lua")
	online_update,online_updold = checkupdate()
	debugaddentry(18)
	if (online_update) and not (online_updold == false) then
		submen = 4
		showupdate = true
		men = online_updold - 1
		if socket_downloadfile("raw.githubusercontent.com", "raw.githubusercontent.com", 443, "/mariohackandglitch/CTGP-7updates/master/array_changelog.lua", 32768, MAX_RAM_ALLOCATION, 10000, System.currentDirectory().."array_changelog.lua", false, nil) then
			dofile(System.currentDirectory().."array_changelog.lua")
			System.deleteFile(System.currentDirectory().."array_changelog.lua")
			got_changelog = true
		else
			online_update = false
		end
	end
	if not (ntrinstalled) then
		submen = 5
		men = 0
	end
	-- Play Sounds
	debugaddentry(19)
	Sound.play(bgm, LOOP)
	Screen.enable3D()
	debugaddentry(20)
	Console.clear(console)
end
System.currentDirectory("/CTGP-7/")
finishinstall()
if not Core.checkService("cam:u") then dofile(System.currentDirectory().."ntr.lua") end
Graphics.init()
font = Font.load(System.currentDirectory().."resources/font.ttf")
console = Console.new(TOP_SCREEN)
Screen.waitVblankStart()
Screen.refresh()
Screen.clear(BOTTOM_SCREEN)
Font.setPixelSizes(font, 32)
Font_center(font, "Loading...", Color.new(255,255,255), BOTTOM_SCREEN)
Screen.flip()
if Controls.check(Controls.read(),KEY_SELECT) then debug_console = true else debug_console = false end
initapp()
while true do
	Sound.updateStream()
	checkbutton = true
	pad = getcontrol()
	Screen.waitVblankStart()
	Screen.refresh()
	Screen.clear(BOTTOM_SCREEN)
	Screen.clear(TOP_SCREEN)
	if (appexit) then
		doexitapp()
	end
	if (submen ~= 2) then
		Graphics.initBlend(TOP_SCREEN,0)
		Graphics.drawImage(0, 0, topimgl)
		Graphics.termBlend()
		Graphics.initBlend(TOP_SCREEN,1)
		Graphics.drawImage(0, 0, topimgr)
		Graphics.termBlend()
		Font.setPixelSizes(font, 16)
		Font.print(font, 4, 224, "Ver. "..local_ver, Color.new(255,255,255),TOP_SCREEN,0)
		Font.print(font, 8, 224, "Ver. "..local_ver, Color.new(255,255,255),TOP_SCREEN,1)
	end
	Console.show(console)
	if (submen == 0) then -- main menu
		if (pad == "Down") then
			men = men + 1
			Sound.play(beep, NO_LOOP)
		elseif (pad == "Up") then
			men = men - 1
			Sound.play(beep, NO_LOOP)
		end
		Font.setPixelSizes(font, 32)
		if (men > 2) then
			men = 0
		elseif (men < 0) then
			men = 2
		end
		if (men == 0) then
			Graphics.initBlend(BOTTOM_SCREEN)
			Graphics.drawImage(0, 0, submen0)
			Graphics.drawImage(5, 15, btn_s)
			Graphics.drawImage(5, 90, btn_u)
			Graphics.drawImage(5, 165, btn_u)
			Graphics.termBlend()
			fred,fgreen,fblue = rainbow()
			Font_center(font, "Launch CTGP-7", Color.new(fred,fgreen,fblue), BOTTOM_SCREEN, nil, 30)
			Font_center(font, "Settings", Color.new(255,255,255), BOTTOM_SCREEN, nil, 105)
			Font_center(font, "Exit", Color.new(255,255,255), BOTTOM_SCREEN, nil, 180)
			if (pad == "A") and (checkbutton) then
				checkbutton = false
				Sound.play(beep, NO_LOOP)
				Sound.pause(bgm)
				Screen.waitVblankStart()
				Screen.refresh()
				Screen.clear(BOTTOM_SCREEN)
				Graphics.initBlend(BOTTOM_SCREEN)
				Graphics.drawImage(0, 0, submen0)
				Graphics.termBlend()
				Font.setPixelSizes(font, 26)
				Font_center(font, "Launch Mario Kart 7", Color.new(255,255,255), BOTTOM_SCREEN, nil, 94)
				Font_center(font, "from home menu.", Color.new(255,255,255), BOTTOM_SCREEN, nil, 120)
				Screen.flip()
				Graphics.initBlend(BOTTOM_SCREEN)
				Graphics.drawImage(0, 0, submen0)
				Graphics.termBlend()
				Font_center(font, "Launch Mario Kart 7", Color.new(255,255,255), BOTTOM_SCREEN, nil, 94)
				Font_center(font, "from home menu.", Color.new(255,255,255), BOTTOM_SCREEN, nil, 120)
				Screen.flip()
				Screen.waitVblankStart()
				Screen.refresh()
				tmptimer = Timer.new()
				while (Timer.getTime(tmptimer) < 1000) do end
				Timer.destroy(tmptimer)
				exitapp()
			end
		elseif (men == 1) then
			Graphics.initBlend(BOTTOM_SCREEN)
			Graphics.drawImage(0, 0, submen0)
			Graphics.drawImage(5, 15, btn_u)
			Graphics.drawImage(5, 90, btn_s)
			Graphics.drawImage(5, 165, btn_u)
			Graphics.termBlend()
			Font_center(font, "Launch CTGP-7", Color.new(255,255,255), BOTTOM_SCREEN, nil, 30)
			Font_center(font, "Settings", Color.new(255,0,0), BOTTOM_SCREEN, nil, 105)
			Font_center(font, "Exit", Color.new(255,255,255), BOTTOM_SCREEN, nil, 180)
			if (pad == "A") and (checkbutton) then
				Sound.play(beep, NO_LOOP)
				submen = 1
				men = 0
				men1 = 0
				checkbutton = false
			end
		elseif (men == 2) then
			Graphics.initBlend(BOTTOM_SCREEN)
			Graphics.drawImage(0, 0, submen0)
			Graphics.drawImage(5, 15, btn_u)
			Graphics.drawImage(5, 90, btn_u)
			Graphics.drawImage(5, 165, btn_s)
			Graphics.termBlend()
			Font_center(font, "Launch CTGP-7", Color.new(255,255,255), BOTTOM_SCREEN, nil, 30)
			Font_center(font, "Settings", Color.new(255,255,255), BOTTOM_SCREEN, nil, 105)
			Font_center(font, "Exit", Color.new(255,0,0), BOTTOM_SCREEN, nil, 180)
			if (pad == "A") and (checkbutton) then
				Sound.play(beep1, NO_LOOP)
				checkbutton = false
				exitapp()
			end
		end
		if (pad == "B") and (checkbutton) then
			Sound.play(beep1, NO_LOOP)
			checkbutton = false
			exitapp()
		end
	end
	if (submen == 1) then -- Options
	Font.setPixelSizes(font, 32)
		if (pad == "Down") then
			men = men + 1
			Sound.play(beep, NO_LOOP)
		elseif (pad == "Up") then
			men = men - 1
			Sound.play(beep, NO_LOOP)
		end
		if (men > 2) then
			men = 0
		elseif (men < 0) then
			men = 2
		end
		if (men == 0) then
			Graphics.initBlend(BOTTOM_SCREEN)
			Graphics.drawImage(0, 0, submen0)
			Graphics.drawImage(5, 15, btn_s)
			Graphics.drawImage(5, 90, btn_u)
			Graphics.drawImage(5, 165, btn_u)
			Graphics.termBlend()
			Font_center(font, "Ingame Settings",Color.new(255,0,0), BOTTOM_SCREEN, nil, 30)
			Font_center(font, "Updates", Color.new(255,255,255), BOTTOM_SCREEN, nil, 105)
			Font_center(font, "Back", Color.new(255,255,255), BOTTOM_SCREEN, nil, 180)
			if (pad == "A") and (checkbutton) then
				Sound.play(beep, NO_LOOP)
				submen = 2
				men = 0
				men1 = 0
				checkbutton = false
			end
		elseif (men == 1) then
			Graphics.initBlend(BOTTOM_SCREEN)
			Graphics.drawImage(0, 0, submen0)
			Graphics.drawImage(5, 15, btn_u)
			Graphics.drawImage(5, 90, btn_s)
			Graphics.drawImage(5, 165, btn_u)
			Graphics.termBlend()
			Font_center(font, "Ingame Settings", Color.new(255,255,255), BOTTOM_SCREEN, nil, 30)
			Font_center(font, "Updates", Color.new(255,0,0), BOTTOM_SCREEN, nil, 105)
			Font_center(font, "Back", Color.new(255,255,255), BOTTOM_SCREEN, nil, 180)
			if (pad == "A") and (checkbutton) then
				Sound.play(beep, NO_LOOP)
				submen = 4
				men = 1
				men1 = 0
				checkbutton = false
			end
		elseif (men == 2) then
			Graphics.initBlend(BOTTOM_SCREEN)
			Graphics.drawImage(0, 0, submen0)
			Graphics.drawImage(5, 15, btn_u)
			Graphics.drawImage(5, 90, btn_u)
			Graphics.drawImage(5, 165, btn_s)
			Graphics.termBlend()
			Font_center(font, "Ingame Settings",Color.new(255,255,255), BOTTOM_SCREEN, nil, 30)
			Font_center(font, "Updates", Color.new(255,255,255), BOTTOM_SCREEN, nil, 105)
			Font_center(font, "Back", Color.new(255,0,0), BOTTOM_SCREEN, nil, 180)
			if (pad == "A") and (checkbutton) then
				Sound.play(beep1, NO_LOOP)
				submen = 0
				men = 1
				men1 = 0
				checkbutton = false
			end
		end
		if (pad == "B") and (checkbutton) then
			Sound.play(beep1, NO_LOOP)
			submen = 0
			men = 1
			men1 = 0
			checkbutton = false
		end
	end
	if (submen == 2) then -- Course manager
		if gotconfig then
			if not (setting_men) then
				Font.setPixelSizes(font, 25)
				if (pad == "Down") then
					men3 = men3 - 1
					Sound.play(beep1, NO_LOOP)
				elseif (pad == "Up") then
					men3 = men3 + 1
					Sound.play(beep1, NO_LOOP)
				end
				if (men3 >= trackn + 1) then
					men3 = 1
				elseif (men3 <= 0) then
					men3 = trackn
				end
				disp1 = men3 + 1
				disp2 = men3 - 1
				if (disp1 >= trackn + 1) then
					disp1 = 1
				elseif (disp1 <= 0) then
					disp1 = trackn
				end
				if (disp2 >= trackn + 1) then
					disp2 = 1
				elseif (disp2 <= 0) then
					disp2 = trackn
				end
				if (pad == "A") and (checkbutton) then
					tracke[men3] = not tracke[men3]
					Sound.play(beep, NO_LOOP)
				end
				if (pad == "Right") and (checkbutton) then
					for p=1, trackn do
						tracke[p] = true
					end
					Sound.play(beep, NO_LOOP)
				elseif (pad == "Left") and (checkbutton) then
					for p=1, trackn do
						tracke[p] = false
					end
					Sound.play(beep, NO_LOOP)
				end
				color_ed = {}
				if (tracke[men3]) then
					btn_y = 52
					color_ed[3] = Color.new(0,255,0)
				else
					btn_y = 0
					color_ed[3] = Color.new(255,0,0)
				end
				Graphics.initBlend(BOTTOM_SCREEN)
				Graphics.drawImage(0, 0, submen0)
				Graphics.drawImage(0, 40, btn_bg)
				Graphics.drawPartialImage(8, 160, 0, btn_y, 304, 52, btn_disen)
				Graphics.termBlend()
				if (tracke[disp1]) then
					color_ed[1] = Color.new(0,153,0)
				else
					color_ed[1] = Color.new(153,0,0)
				end
				if (tracke[disp2]) then
					color_ed[2] = Color.new(0,153,0)
				else
					color_ed[2] = Color.new(153,0,0)
				end
				if (men3 < 10) then
					curr_cour = "0"..tostring(men3)
				else
					curr_cour = tostring(men3)
				end
				Font_center(font, curr_cour.." / "..trackn, Color.new(255,255,255), BOTTOM_SCREEN, nil, 135)
				Font_center(font, "Page 1 / 2", Color.new(255,255,255), BOTTOM_SCREEN, nil, 8)
				Font_center(font, cts[disp1], color_ed[1], BOTTOM_SCREEN, nil, 50)
				Font_center(font, cts[men3], color_ed[3], BOTTOM_SCREEN, nil, 75)
				Font_center(font, cts[disp2], color_ed[2], BOTTOM_SCREEN, nil, 100)
				Graphics.initBlend(TOP_SCREEN,0)
				Graphics.drawImage(0, 0, topimgl)
				Graphics.termBlend()
				Graphics.initBlend(TOP_SCREEN,1)
				Graphics.drawImage(0, 0, topimgr)
				Graphics.termBlend()
				Font.setPixelSizes(font, 16)
				Font.print(font, 4, 224, "Ver. "..local_ver, Color.new(255,255,255),TOP_SCREEN,0)
				Font.print(font, 8, 224, "Ver. "..local_ver, Color.new(255,255,255),TOP_SCREEN,1)
				Font.setPixelSizes(font, 14)
				Font_center(font,"A: Enable/disable, Y: Change Page, B: Exit", Color.new(255,255,255), BOTTOM_SCREEN, nil, 212)
				Font_center(font,"Left: Disable All, Right: Enable All", Color.new(255,255,255), BOTTOM_SCREEN, nil, 226)
			elseif (setting_men) then
				if (pad == "Down") or (pad == "Up") and (checkbutton) then
					men3 = math.abs(men3 - 1)
					Sound.play(beep1, NO_LOOP)
				end
				if (men3 == 0) then
					color_200cc = Color.new(255,255,255)
					color_LED = Color.new(128,128,128)
				else
					color_LED = Color.new(255,255,255)
					color_200cc = Color.new(128,128,128)
				end
				if (settings[1]) then
					ccbtn_y = 52
				else
					ccbtn_y = 0
				end
				if (settings[2]) then
					ledbtn_y = 52
				else
					ledbtn_y = 0
				end
				Graphics.initBlend(TOP_SCREEN,0)
				Graphics.drawImage(0, 0, topimgl)
				Graphics.drawImage(41, 128, btn_wr)
				Graphics.termBlend()
				Graphics.initBlend(TOP_SCREEN,1)
				Graphics.drawImage(0, 0, topimgr)
				Graphics.drawImage(39, 128, btn_wr)
				Graphics.termBlend()
				Font.setPixelSizes(font, 16)
				Font.print(font, 4, 224, "Ver. "..local_ver, Color.new(255,255,255),TOP_SCREEN,0)
				Font.print(font, 8, 224, "Ver. "..local_ver, Color.new(255,255,255),TOP_SCREEN,1)
				Font_center(font, "Online is disabled if 200cc is enabled.", Color.new(255,255,255), TOP_SCREEN, nil, 145, 4)
				Font_center(font, "To use it, press X+Y after CTGP-7 boot,", Color.new(255,255,255), TOP_SCREEN, nil, 161, 4)
				Font_center(font, "select Game Plugin and enable 200cc.", Color.new(255,255,255), TOP_SCREEN, nil, 177, 4)
				Font_center(font, "LED tricks only work in Time Trials.", Color.new(255,255,255), TOP_SCREEN, nil, 193, 4)
				Graphics.initBlend(BOTTOM_SCREEN)
				Graphics.drawImage(0, 0, submen0)
				Graphics.drawImageExtended(160, 87, 0, ccbtn_y, 304, 52, 0, 1, 1, btn_disen, color_200cc)
				Graphics.drawImageExtended(160, 178, 0, ledbtn_y, 304, 52, 0, 1, 1, btn_disen, color_LED)
				Graphics.termBlend()
				Font.setPixelSizes(font, 25)
				Font_center(font, "Page 2 / 2", Color.new(255,255,255), BOTTOM_SCREEN, nil, 8)
				Font_center(font,"200cc", color_200cc, BOTTOM_SCREEN, nil, 36)
				Font_center(font,"LED tricks", color_LED, BOTTOM_SCREEN, nil, 127)
				Font.setPixelSizes(font, 14)
				Font_center(font,"A: Enable/disable, Y: Change Page, B: Exit", Color.new(255,255,255), BOTTOM_SCREEN, nil, 213)
				if (pad == "A") and (men3 == 0) and (checkbutton) then
					settings[1] = not settings[1]
					Sound.play(beep, NO_LOOP)
				elseif (pad == "A") and (men3 == 1) and (checkbutton) then
					settings[2] = not settings[2]
					Sound.play(beep, NO_LOOP)
				end
			end
			if (pad == "Y") and (checkbutton) then
				setting_men = not setting_men
				Sound.play(beep, NO_LOOP)
				men3 = 0
			end
			if (pad == "B") and (checkbutton) then
				Sound.play(beep1, NO_LOOP)
				submen = 1
				men = 0
				men3 = 0
				checkbutton = false
				applyconfig()
			end
		else
			Graphics.initBlend(BOTTOM_SCREEN)
			Graphics.drawImage(0, 0, submen0)
			Graphics.termBlend()
			Font.setPixelSizes(font, 20)
			Font.print(font, 5, 0,"You have different number", Color.new(255,255,255), BOTTOM_SCREEN)
			Font.print(font, 5, 25,"of CTs than expected.", Color.new(255,255,255), BOTTOM_SCREEN)
			Font.print(font, 5, 75,"CT manager won't work.", Color.new(255,255,255), BOTTOM_SCREEN)
			Font.print(font, 5, 125,"(You have: "..trackn..", expected: "..#cts..")", Color.new(255,255,255), BOTTOM_SCREEN)
			Font.print(font, 5, 203,"Press B to exit", Color.new(255,255,255), BOTTOM_SCREEN)
			if (pad == "B") and (checkbutton) then
				Sound.play(beep1, NO_LOOP)
				submen = 1
				men = 0
				checkbutton = false
			end
		end
	end
	if (submen == 4) then -- Update CTGP-7
		if not (got_changelog) then
			if (online_update) then
				if socket_downloadfile("raw.githubusercontent.com", "raw.githubusercontent.com", 443, "/mariohackandglitch/CTGP-7updates/master/array_changelog.lua", 32768, MAX_RAM_ALLOCATION, 10000, System.currentDirectory().."array_changelog.lua", false, nil) then
					dofile(System.currentDirectory().."array_changelog.lua")
					System.deleteFile(System.currentDirectory().."array_changelog.lua")
					got_changelog = true
				else
					online_update = false
				end
			end
		end
		Font.setPixelSizes(font, 16)
		Graphics.initBlend(BOTTOM_SCREEN)
		Graphics.drawImage(0, 0, submen0)
		Graphics.termBlend()
		if (online_update) then				
			if (pad == "Down") then
				men = men + 1
				Sound.play(beep, NO_LOOP)
			elseif (pad == "Up") then
				men = men - 1
				Sound.play(beep, NO_LOOP)
			end
			if (men > uinfo_entries) then
				men = uinfo_entries
			elseif (men < 1) then
				men = 1
			end
			online_version = array_ver[men]
			online_changelog = array_changelog[men]
			if (online_updold ~= false) and (online_updold > men) then
				pressto = ", START: Update"
			else
				pressto = ""
			end
			online_entries = #online_changelog
			clog_pages = 0
			while (online_entries > 0) do
				online_entries = online_entries - 9
				clog_pages = clog_pages + 1				
			end
			online_entries = #online_changelog
			if (pad == "Right") then
				clog_page = clog_page + 1
				Sound.play(beep, NO_LOOP)
			elseif (pad == "Left") then
				clog_page = clog_page - 1
				Sound.play(beep, NO_LOOP)
			end
			if (clog_page > clog_pages) then
				clog_page = clog_pages
			elseif (clog_page < 1) then
				clog_page = 1
			end
			for clog = 1, 9, 1 do
				if (online_changelog[clog + ((clog_page - 1)*9)] == nil) then
					break
				end
				Font.print(font, 5, ((clog * 16) + 32), online_changelog[clog + ((clog_page - 1)*9)], Color.new(255,255,255), BOTTOM_SCREEN)
			end
			Font_center(font,"Version: "..online_version, Color.new(255,255,255), BOTTOM_SCREEN, nil, 0)
			Font_center(font,"Changelog: (Page: "..clog_page.." of "..clog_pages..")", Color.new(255,255,255), BOTTOM_SCREEN, nil, 16)
			Font_center(font,"----------------------------------------------------", Color.new(255,255,255), BOTTOM_SCREEN, nil, 32)
			Font_center(font,"----------------------------------------------------", Color.new(255,255,255), BOTTOM_SCREEN, nil, 192)
			Font_center(font,"Left/Right: Page, Up/Down: Version", Color.new(255,255,255), BOTTOM_SCREEN, nil, 208)
			Font_center(font,"A/B: Return"..pressto, Color.new(255,255,255), BOTTOM_SCREEN, nil, 224)
		else
			Font_center(font,"Couldn't get update data.", Color.new(255,255,255), BOTTOM_SCREEN, nil, 0)
			Font_center(font,"A/B: Return", Color.new(255,255,255), BOTTOM_SCREEN, nil, 224)
		end
		if (pad == "START") and (checkbutton) and (online_updold ~= false) and (online_updold > men) then
			for p=1, trackn do
				tracke[p] = true
			end
			applyconfig()
			Screen.disable3D()
			Sound.play(beep, NO_LOOP)
			Sound.pause(bgm)
			checkbutton = false
			startupdate(online_updold - 1)
		end
		if ((pad == "B") and (checkbutton)) or ((pad == "A") and (checkbutton)) then
			Sound.play(beep1, NO_LOOP)
			if (showupdate) then
				submen = 0
				showupdate = false
			else
				submen = 1
				men = 1
			end
			checkbutton = false
		end
	end
	if (submen == 5) then -- Update BootNTR
		Font.setPixelSizes(font, 18)
		Graphics.initBlend(BOTTOM_SCREEN)
		Graphics.drawImage(0, 0, submen0)
		Graphics.termBlend()
		if not (ntrinstalled) then
			Font_center(font,"Boot ntr not detected", Color.new(255,255,255), BOTTOM_SCREEN, nil, 0)
			Font_center(font,"you need to install it to use CTGP-7", Color.new(255,255,255), BOTTOM_SCREEN, nil, 18)
			Font_center(font,"Press A to install or B to cancel.", Color.new(255,255,255), BOTTOM_SCREEN, nil, 36)
		else
			Font_center(font,"Would you like to download", Color.new(255,255,255), BOTTOM_SCREEN, nil, 0)
			Font_center(font,"lastest BootNTR version?", Color.new(255,255,255), BOTTOM_SCREEN, nil, 18)
			Font_center(font,"Press A to update or B to cancel.", Color.new(255,255,255), BOTTOM_SCREEN, nil, 36)
		end
		if (pad == "A") and (checkbutton) then
			Sound.play(beep, NO_LOOP)
			Sound.pause(bgm)
			if (Network.isWifiEnabled()) then
				--
				Screen.disable3D()
				Screen.waitVblankStart()
				Screen.refresh()
				Graphics.initBlend(BOTTOM_SCREEN)
				Graphics.drawImage(0, 0, submen0)
				Graphics.termBlend()
				Font_center(font,"Downloading...", Color.new(255,255,255), BOTTOM_SCREEN)
				Screen.flip()
				--
				System.deleteDirectory(System.currentDirectory().."ntr")
				System.createDirectory(System.currentDirectory().."ntr")
				socket_downloadfile("raw.githubusercontent.com", "raw.githubusercontent.com", 443, "/mariohackandglitch/CTGP-7updates/master/ntr.zip", 32768, MAX_RAM_ALLOCATION, 10000, System.currentDirectory().."ntr/ntr.zip", true, "ntr")
				if not (System.doesFileExist(System.currentDirectory().."ntr/ntr.zip")) then
					--
					Screen.waitVblankStart()
					Screen.refresh()
					Screen.clear(BOTTOM_SCREEN)
					Graphics.initBlend(BOTTOM_SCREEN)
					Graphics.drawImage(0, 0, submen0)
					Graphics.termBlend()
					Font_center(font,"Download failed,", Color.new(255,255,255), BOTTOM_SCREEN)
					--
					exitapp()
				end
				--
				Screen.waitVblankStart()
				Screen.refresh()
				Screen.clear(BOTTOM_SCREEN)
				Graphics.initBlend(BOTTOM_SCREEN)
				Graphics.drawImage(0, 0, submen0)
				Graphics.termBlend()
				Font_center(font,"Extracting...", Color.new(255,255,255), BOTTOM_SCREEN)
				Screen.flip()
				--
				System.extractZIP(System.currentDirectory().."ntr/ntr.zip",System.currentDirectory().."ntr")
				--
				if (ntrinstalled) then
					--
					Screen.waitVblankStart()
					Screen.refresh()
					Graphics.initBlend(BOTTOM_SCREEN)
					Graphics.drawImage(0, 0, submen0)
					Graphics.termBlend()
					Font_center(font,"Uninstalling...", Color.new(255,255,255), BOTTOM_SCREEN)
					Screen.flip()
					--
					if (cia_list[ntrlist_id].unique_id == 0x00b00000) then
						System.uninstallCIA(cia_list[ntrlist_id].access_id,SDMC)
					else
						exitapp()
					end
				end
				Screen.waitVblankStart()
				Screen.refresh()
				Graphics.initBlend(BOTTOM_SCREEN)
				Graphics.drawImage(0, 0, submen0)
				Graphics.termBlend()
				Font_center(font,"Installing...", Color.new(255,255,255), BOTTOM_SCREEN)
				Screen.flip()
				--
				System.installCIA(System.currentDirectory().."ntr/ntr.cia",1)
				System.deleteFile("/ntr.bin")
				System.renameFile(System.currentDirectory().."ntr/ntr.bin","/ntr.bin")
				System.deleteFile(System.currentDirectory().."ntr/ntr.zip")
				System.deleteFile(System.currentDirectory().."ntr/ntr.cia")
				System.deleteDirectory(System.currentDirectory().."ntr")
				--
				Screen.waitVblankStart()
				Screen.refresh()
				Graphics.initBlend(BOTTOM_SCREEN)
				Graphics.drawImage(0, 0, submen0)
				Graphics.termBlend()
				Font_center(font,"Done!", Color.new(255,255,255), BOTTOM_SCREEN)
				exitapp()
			else
				Screen.waitVblankStart()
				Screen.refresh()
				Graphics.initBlend(BOTTOM_SCREEN)
				Graphics.drawImage(0, 0, submen0)
				Graphics.termBlend()
				Font_center(font,"No internet access", Color.new(255,255,255), BOTTOM_SCREEN)
				exitapp()
			end
		elseif (pad == "B") and (checkbutton) then
			Sound.play(beep1, NO_LOOP)
			checkbutton = false
			if not (ntrinstalled) then
				exitapp()
			else
				submen = 3
				checkbutton = false
			end
		end
	end
	if Controls.check(Controls.read(),KEY_HOME) or Controls.check(Controls.read(),KEY_POWER) then
		exitapp()
	end
	if (Timer.getTime(rnbw_timer) >= 3100) then
		Timer.reset(rnbw_timer)
	end
	oldpad = pad
	Screen.flip()
end