function startupdate(update_old)
	update_ver = array_ver[update_old]
	--Screen Draw
	Screen.waitVblankStart()
	Screen.refresh()
	Font.setPixelSizes(font, 24)
	Graphics.initBlend(BOTTOM_SCREEN)
	Graphics.drawImage(0, 0, submen0)
	Graphics.termBlend()
	Font_center(font, "Downloading "..update_ver.."...",Color.new(255,0,0), BOTTOM_SCREEN, nil, 10)
	Font_center(font, "Installing "..update_ver.."...",Color.new(255,255,255), BOTTOM_SCREEN, nil, 50)
	Screen.flip()
	--Download zip.
	if not Network.isWifiEnabled() then
		doexitapp()
	end
	System.deleteDirectory(System.currentDirectory().."updates")
	System.createDirectory(System.currentDirectory().."updates")
	socket_downloadfile("raw.githubusercontent.com", "raw.githubusercontent.com", 443, "/mariohackandglitch/CTGP-7updates/master/"..update_ver..".zip", 32768, MAX_RAM_ALLOCATION, 10000, System.currentDirectory().."updates/"..update_ver..".zip", true, "update")
	Font.setPixelSizes(font, 24)
	if not System.doesFileExist(System.currentDirectory().."updates/"..update_ver..".zip") then
		doexitapp()
	end
	--Screen Draw
	Screen.waitVblankStart()
	Screen.refresh()
	Screen.clear(BOTTOM_SCREEN)
	Graphics.initBlend(BOTTOM_SCREEN)
	Graphics.drawImage(0, 0, submen0)
	Graphics.termBlend()
	Font_center(font, "Downloading "..update_ver.." Done!",Color.new(255,255,255), BOTTOM_SCREEN, nil, 10)
	Font_center(font, "Installing "..update_ver.."...",Color.new(255,0,0), BOTTOM_SCREEN, nil, 50)
	Screen.flip()
	--Extract zip
	System.extractZIP(System.currentDirectory().."updates/"..update_ver..".zip",System.currentDirectory())
	--Exit app
	Screen.waitVblankStart()
	Screen.refresh()
	Screen.clear(BOTTOM_SCREEN)
	Graphics.initBlend(BOTTOM_SCREEN)
	Graphics.drawImage(0, 0, submen0)
	Graphics.termBlend()
	Font_center(font, "Downloading "..update_ver.." Done!",Color.new(255,255,255), BOTTOM_SCREEN, nil, 10)
	Font_center(font, "Installing "..update_ver.." Done!",Color.new(255,255,255), BOTTOM_SCREEN, nil, 50)
	Screen.flip()
	System.deleteFile(System.currentDirectory().."updates/"..update_ver..".zip")
	Screen.waitVblankStart()
	Screen.refresh()
	Screen.clear(TOP_SCREEN)
	Screen.clear(BOTTOM_SCREEN)
	Screen.flip()
	Screen.waitVblankStart()
	Screen.refresh()
	Screen.clear(TOP_SCREEN)
	Screen.clear(BOTTOM_SCREEN)
	Screen.flip()
	tmptmr = Timer.new()
	while (Timer.getTime(tmptmr) < 1000) do end
	Timer.destroy(tmptmr)
	dofile(System.currentDirectory().."script.lua")
end