function getntrcontrol()
	GC_key = Controls.read()
	GC_x,GC_y = Controls.readCirclePad()
	GC_outkey = ""
	if (Controls.check(GC_key,KEY_A)) and not(Controls.check(GC_oldkey,KEY_A)) then
		GC_outkey = "A"
	elseif (Controls.check(GC_key,KEY_B)) and not(Controls.check(GC_oldkey,KEY_B)) then
		GC_outkey = "B"
	elseif (Controls.check(GC_key,KEY_Y)) then
		GC_outkey = "Y"
	elseif (Controls.check(GC_key,KEY_START)) and not(Controls.check(GC_oldkey,KEY_START)) then
		GC_outkey = "START"
	end
	if (Timer.getTime(ctrl_timer) >= 500) then
		Timer.reset(ctrl_timer)
		GC_oldkey = KEY_X
		GC_oldx = 0
		GC_oldy = 0
	end
	if (((Controls.check(GC_key,KEY_DLEFT)) and not(Controls.check(GC_oldkey,KEY_DLEFT))) or ((GC_x < -128) and not (GC_oldx < -128))) then
		GC_outkey = "Left"
		Timer.reset(ctrl_timer)
	elseif (((Controls.check(GC_key,KEY_DRIGHT)) and not(Controls.check(GC_oldkey,KEY_DRIGHT))) or ((GC_x > 128) and not (GC_oldx > 128))) then
		GC_outkey = "Right"
		Timer.reset(ctrl_timer)
	elseif (((Controls.check(GC_key,KEY_DUP)) and not(Controls.check(GC_oldkey,KEY_DUP))) or ((GC_y > 128) and not (GC_oldy > 128))) then
		GC_outkey = "Up"
		Timer.reset(ctrl_timer)
	elseif (((Controls.check(GC_key,KEY_DDOWN)) and not(Controls.check(GC_oldkey,KEY_DDOWN))) or ((GC_y < -128) and not (GC_oldy < -128))) then
		GC_outkey = "Down"
		Timer.reset(ctrl_timer)
	end
	GC_oldkey = GC_key
	GC_oldx = GC_x
	GC_oldy = GC_y
	return GC_outkey
end
function initntrapp()
	-- Bool
	decided = false
	count = true
	ntrbooted = true
	ntrlua = true
	-- Int
	resttmr = 4000
	MAX_RAM_ALLOCATION = 10485760
	model = System.getModel()
	if (model == 2) or (model == 4) then
		maxmen = 3
	else
		maxmen = 2
	end
	-- Control
	opt = {}
	sel = {}
	GC_key = 0
	GC_x,GC_y = 0
	GC_oldkey = GC_key
	GC_oldx = GC_x
	GC_oldy = GC_y
	-- Config
	GC_key = Controls.read()
	GC_oldkey = GC_key
	if not (System.doesFileExist(System.currentDirectory().."config/ntr.flag")) then
		ntrflag = io.open(System.currentDirectory().."config/ntr.flag",FCREATE)
		io.write(ntrflag,0,"1", 1)
		io.close(ntrflag)
		men = 1
	else
		ntrflag = io.open(System.currentDirectory().."config/ntr.flag",FREAD)
		men = tonumber(io.read(ntrflag,0,1))
		io.close(ntrflag)
	end
	-- Timer
	ctrl_timer = Timer.new()
end
System.currentDirectory("/CTGP-7/")
Graphics.init()
font = Font.load(System.currentDirectory().."resources/font.ttf")
initntrapp()
waittmr = Timer.new()
while true do
	checkbutton = true
	pad = getntrcontrol()
	Screen.waitVblankStart()
	Screen.refresh()
	Screen.clear(BOTTOM_SCREEN)
	while (resttmr >= 0) and (decided == false) do
		pad = getntrcontrol()
		Font.setPixelSizes(font, 24)
		Screen.waitVblankStart()
		Screen.refresh()
		Screen.clear(BOTTOM_SCREEN)
		if (pad == "Up") then
			men = men - 1
			count = false
		elseif (pad == "Down") then
			men = men + 1
			count = false
		end
		if (men < 1) then
			men = maxmen
		elseif (men > maxmen) then
			men = 1
		end
		for i = 1, maxmen, 1 do
			opt[i] = Color.new(255,255,255)
			sel[i] = ""
		end
		opt[men] = Color.new(255,0,0)
		sel[men] = "-> "
		if (count) then
			resttmr = 4000 - Timer.getTime(waittmr)
			Font_center(font, "Launching NTR in "..math.modf(resttmr/1000).." sec.",Color.new(255,255,255), BOTTOM_SCREEN, nil, 68)
		else
			Font_center(font, "Select NTR version.",Color.new(255,255,255), BOTTOM_SCREEN, nil, 68)
		end
		Font_center(font, sel[1].."NTR v3.2",opt[1], BOTTOM_SCREEN, nil, 94)
		Font_center(font, sel[2].."NTR v3.3",opt[2], BOTTOM_SCREEN, nil, 120)
		if (maxmen == 3) then
			Font_center(font, sel[3].."NTR v3.4",opt[3], BOTTOM_SCREEN, nil, 146)
		end
		Font.setPixelSizes(font, 14)
		Font_center(font,"A: Confirm, Up/Down: Select, B: Exit", Color.new(255,255,255), BOTTOM_SCREEN, nil, 219)
		if (pad == "A") then
			decided = true
		end
		if (pad == "B") then
			Font.unload(font)
			System.exit()
		end
		Screen.flip()
	end
	for i = 1, maxmen, 1 do
			opt[i] = Color.new(255,255,255)
			sel[i] = ""
	end
	opt[men] = Color.new(0,255,0)
	sel[men] = "-> "
	Screen.waitVblankStart()
	Screen.refresh()
	Screen.clear(BOTTOM_SCREEN)
	Font.setPixelSizes(font, 24)
	Font_center(font, "Launching NTR.",Color.new(255,255,255), BOTTOM_SCREEN, nil, 68)
	Font_center(font, sel[1].."NTR v3.2",opt[1], BOTTOM_SCREEN, nil, 94)
	Font_center(font, sel[2].."NTR v3.3",opt[2], BOTTOM_SCREEN, nil, 120)
	if (maxmen == 3) then
		Font_center(font, sel[3].."NTR v3.4",opt[3], BOTTOM_SCREEN, nil, 146)
	end
	Screen.flip()
	Timer.destroy(waittmr)
	ntrflag = io.open(System.currentDirectory().."config/ntr.flag",FWRITE)
	io.write(ntrflag,0,tostring(men), 1)
	io.close(ntrflag)
	ntr_error = System.bootNTR(men - 1)
	if not (ntr_error.boot) then
		pad = getntrcontrol()
		if not (ntr_error.err1 == nil) then
			ntr_error.err1 = "#"..ntr_error.err1.."\n"
		else
			ntr_error.err1 = ""
		end
		if not (ntr_error.err2 == nil) then
			ntr_error.err2 = "#"..ntr_error.err2.."\n"
		else
			ntr_error.err2 = ""
		end
		if not (ntr_error.err3 == nil) then
			ntr_error.err3 = "#"..ntr_error.err3.."\n"
		else
			ntr_error.err3 = ""
		end
		while true do
			pad = getntrcontrol()
			Font.setPixelSizes(font, 16)
			Screen.waitVblankStart()
			Screen.refresh()
			Screen.clear(BOTTOM_SCREEN)
			Font_center(font, "Failed to boot NTR:\n\n"..ntr_error.err1..ntr_error.err2..ntr_error.err3.."\nReboot and try again.\nA: Continue, B: Reboot",Color.new(255,255,255), BOTTOM_SCREEN)
			Screen.flip()
			if (pad == "B") then
				Font.unload(font)
				System.reboot()
			elseif (pad == "A") then
				Font.unload(font)
				Screen.waitVblankStart()
				Screen.refresh()
				Screen.clear(BOTTOM_SCREEN)
				Screen.flip()
				ntrbooted = false
				dofile(System.currentDirectory().."script.lua")
			end
		end
	end
		Font.unload(font)
		Screen.waitVblankStart()
		Screen.refresh()
		Screen.clear(BOTTOM_SCREEN)
		Screen.flip()
		dofile(System.currentDirectory().."script.lua")
end